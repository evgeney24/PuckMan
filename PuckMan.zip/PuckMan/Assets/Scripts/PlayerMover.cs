﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MazeMover))]
public class PlayerMover : MonoBehaviour
{
    public GameObject Player;
    MazeMover mazeMover;
    Vector2Int newDir;
    EnemyMover[] EnemyMoverS;

    // Start is called before the first frame update
    void Start()
    {
        mazeMover = this.GetComponent<MazeMover>();
        EnemyMoverS = GameObject.FindObjectsOfType<EnemyMover>();
    }
    // Update is called once per frame
    void Update()
    {
        newDir = TakeInputDir();
        mazeMover.direction = mazeMover.SetDirection(newDir);
        foreach (EnemyMover EM in EnemyMoverS)
        {
            //Debug.Log(TileTypeAt(myTileMap.WorldToCell(PE.transform.position)));
            if (Vector3.Distance(this.transform.position, EM.transform.position) <= 0.5)
            {
                Debug.Log("DIE");
                Object.Destroy(Player);
            }
        }
    }

    Vector2Int TakeInputDir()
    {
        Vector2Int dir = new Vector2Int ((int) Input.GetAxisRaw("Horizontal"), (int) Input.GetAxisRaw("Vertical"));
        if (Mathf.Abs(dir.x) >= Mathf.Abs(dir.y))
        {
            dir.y = 0;
        }
        else
        {
            dir.x = 0;
        }
        return dir;
    }
}
