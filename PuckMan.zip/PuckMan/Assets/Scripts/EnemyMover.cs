﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMover : MonoBehaviour
{
    Vector2 newDir;
    
    // Start is called before the first frame update
    void Start()
    {
        mazeMover = GetComponent<MazeMover>();
        mazeMover.OnEnterNewTile += OnEnterNewTile;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    MazeMover mazeMover;
    void OnEnterNewTile() 
    {
        /*int R = Random.Range(0, 4);
        newDir.x = R / 2*/
        Vector2Int newDir = Vector2Int.zero;
        if (Random.Range(0, 2) == 0)
        {
            newDir.x = Random.Range(0, 2) == 0 ? -1 : 1;
        }
        else
        {
            newDir.y = Random.Range(0, 2) == 0 ? -1 : 1;
        }
        mazeMover.direction = mazeMover.SetDirection(newDir);
    }
}
