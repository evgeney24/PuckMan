using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class MazeMover : MonoBehaviour
{
	
    float Speed = 3f;
    public Vector2Int direction = new Vector2Int(0, 0);
    public Vector2Int TargetTile;
    public Tilemap wallTileMap;
    public delegate void OnEnterNewTileDelegate();
    public event OnEnterNewTileDelegate OnEnterNewTile;

    // Start is called before the first frame update
    void Start()
    {
        TargetTile = (Vector2Int) CurrentTile();
        OnEnterNewTile += OnEnterNewTile;
    }

    // Update is called once per frame
    void Update()
    {
        TargetTile = UpdatedTargetPos();
        DoMove();
    }

    /*void _OnEntwrTile () 
    {
        
    }*/
    TileBase GetTileAt(Vector2 pos)
    {
        return wallTileMap.GetTile(TilePos(pos));  
    }
    /*TileBase GetTileAt(Vector2Int tilepos)
    {
        return wallTileMap.GetTile((Vector3) tilepos);
    }*/
    bool IsTilePresent(Vector2 pos)
    {
        return GetTileAt(pos) != null;
    }
    bool IsDirectionLegal(Vector2 dir)
    {
        Vector2 pos = (Vector2)this.transform.position + dir;
        return !IsTilePresent(pos);
    }
    bool IsPosLegal(Vector2 pos)
    {
        return !IsTilePresent(pos);
    }
    Vector2Int UpdatedTargetPos()
    {
        if (Vector2.Distance(this.transform.position, TargetTile) == 0)
        {
            if (OnEnterNewTile != null)
            {
                OnEnterNewTile();
            }
        }
        if (Vector2.Distance(this.transform.position, TargetTile) == 0 && IsDirectionLegal(direction))
        {
            return TargetTile + direction;
        }
        if (Vector2.Dot(direction, TargetTile - (Vector2) this.transform.position) < 0 && IsDirectionLegal(direction))
        {
            return TargetTile + direction;
        }
        return TargetTile;
    }
    public Vector2Int SetDirection(Vector2Int newDir)
    {
        Vector2Int Dir = direction;
        Vector2Int TestPos = (Vector2Int) CurrentTile();
        if ((IsDirectionLegal(newDir) || Vector2.Dot(newDir, TestPos - (Vector2)this.transform.position) > 0) && newDir.magnitude != 0)
        {
            if (Dir != newDir)
            {
                TargetTile = TestPos;
                //Debug.Log("x = " + newDir.x + ", y = " + newDir.y);
            }
            Dir = newDir;
        }
        return Dir;
    }
    void DoMove()
    {
        //this.transform.Translate(direction * Speed * Time.deltaTime);
        this.transform.position = Vector2.MoveTowards(this.transform.position, TargetTile, Speed * Time.deltaTime);
    }
    Vector3Int TilePos(Vector2 pos) 
    {
        return wallTileMap.WorldToCell(pos);
    }
    Vector3Int CurrentTile () 
    {
        return TilePos(this.transform.position);
    }

}
/*
 * if (Dir.x==0 && Mathf.Abs(Mathf.RoundToInt (this.transform.position.x.)-this.transform.position.x.) >= 0.01)
 * {
 *   
 * }
 * if (Dir.x==0 && Mathf.Abs(Mathf.RoundToInt (this.transform.position.x.)-this.transform.position.x.) >= 0.01)
 * {
 * 
 * }
 * DoMove (Dir)
 * 
 * 
 * 
if (Input.GetAxisRaw("Horizontal") != 0)
{
    newDir = (GetAxisRaw("Horizontal"), 0);
}

if (Input.GetAxisRaw("Vertical") != 0)
{
    newDir = (0, GetAxisRaw("Vertical"));
}*/