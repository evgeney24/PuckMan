﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class PelletTileMap : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        myTileMap = GetComponent<Tilemap>();
        PelletEaterS = GameObject.FindObjectsOfType<PelletEater>();
    }

    // Update is called once per frame
    void Update()
    {
        foreach (PelletEater PE in PelletEaterS) 
        {
            //Debug.Log(TileTypeAt(myTileMap.WorldToCell(PE.transform.position)));
            if (IsPelletOnTile(PE))
            {

                //pelletNames PNE = 0;
                //PNE.TryParse();
                //string PN = TileTypeAt(myTileMap.WorldToCell(PE.transform.position));
                EatPellet(PE);
                Debug.Log ("NOM");
            }
        }
    }

    PelletEater[] PelletEaterS;
    Tilemap myTileMap;
    enum pelletNames {empty, pellet, powerPellet, Fruit00}
    int pelletPoint = 1;
    bool IsRequiredForLevelComplition = true;
    float PowerSeconds = 0;

    bool IsPelletOnTile (PelletEater PE) 
    {
        TileBase T =GetTileAt((Vector2)PE.transform.position);
        return (T != null);
    }

    TileBase GetTileAt(Vector2 pos)
    {
        return myTileMap.GetTile(myTileMap.WorldToCell(pos));
    }
    bool IsTilePresent(Vector2 pos)
    {
        return GetTileAt(pos) != null;
    }
    void EatPellet(PelletEater PE)
    {
        Vector3Int tilePos = myTileMap.WorldToCell(PE.transform.position);
        TileBase tile = null;
        Debug.Log(TileTypeAt(tilePos));
        myTileMap.SetTile(tilePos, tile);
    }
    /*TileBase SetTileAt(Vector3Int tilePos, TileBase tile) 
    {
        return myTileMap.SetTile(tilePos, tile);
    }*/
    string TileTypeAt(Vector3Int tilePos)
    {
        TileBase tile = myTileMap.GetTile(tilePos);
        if (tile == null) 
        {
            return "empty";
        }
        return tile.name;
    }

}
